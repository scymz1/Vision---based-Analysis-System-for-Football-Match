from django.shortcuts import render
from django.http import HttpResponse
from django.http import StreamingHttpResponse
from .form import UploadFileForm
from django.views.decorators.csrf import csrf_exempt
from NewDjango import settings
import os
import sys
import shutil
from wsgiref.util import FileWrapper


#change the path next line to be the location of the start function
#sys.path.append(r'/home/zmh/grp')
#import (the .py file which contains the start function)

def handle_uploaded_file(f, filename):
    filename_path: str = f'{"../../SiamMask/Video/"}{filename}'  # 生成文件名及路径
    with open(filename_path, 'wb+') as destination:
        for chunk in f.chunks():
            destination.write(chunk)
        destination.close()
        return HttpResponse('file for upload ok')


def receive_video(request):
    #this is the function called when a video is received from the front end
    if request.method == 'POST':
        delete_path = "../../SiamMask/Video/"
        del_list = os.listdir(delete_path)
        for f in del_list:
            file_path = os.path.join(delete_path, f)
            if os.path.isfile(file_path) :
                os.remove(file_path)
            elif os.path.isdir(file_path) :
                shutil.rmtree(file_path)
        forms = UploadFileForm(request.POST, request.FILES)
        print('received!')
        if forms.is_valid():
            print("a " + request.method + " request occurs!")
            handle_uploaded_file(request.FILES['file'], filename=request.FILES.get('file'))
            return HttpResponse('file for upload ok')


@csrf_exempt
def index(request):
    #this is the function called when a video is received from the front end
    '''if request.method == 'POST':
        delete_path = "../../SiamMask/Video/"
        del_list = os.listdir(delete_path)
        for f in del_list:
            file_path = os.path.join(delete_path, f)
            if os.path.isfile(file_path) :
                os.remove(file_path)
            elif os.path.isdir(file_path) :
                shutil.rmtree(file_path)
        forms = UploadFileForm(request.POST, request.FILES)
        print('received!')
        if forms.is_valid():
            print("a " + request.method + " request occurs!")
            handle_uploaded_file(request.FILES['file'], filename=request.FILES.get('file'))
            return HttpResponse('file for upload ok')'''

    #this is the function called when the front end requires data to draw the graphs
    if request.method == 'GET':
        #call the start function here, set res equals to the return result
        top = request.GET.get("top", default='0')
        left = request.GET.get("left", default='0')
        height = request.GET.get("height", default='0')
        width = request.GET.get("width", default='0')
        print(left + " " + top + " " + width + " " + height + "aaaaaaaaaaaaaaaaaaaaaaa")
        os.system("bash ../../execute.sh " + left + " " + top + " " + width + " " + height)
        BASE_DIR = os.path.dirname(os.path.abspath(__file__))
        result_file = "../../SiamMask/Video/processed/processed.mp4"
        if not  os.path.exists(result_file):
            #return HttpResponse(content="file not exist!", status=200)
            return HttpResponse(content=result_file, status=200)
        else:
            return HttpResponse("new video generated")
    else:
        print("a " + request.method + " request occurs!")
        return HttpResponse('Wrong Method!')
    return HttpResponse('file for upload ok')
    
def download(request):
    result_file = "../../SiamMask/Video/processed/processed.mp4"
    if not  os.path.exists(result_file):
        print("aaaaaaaaaa")
    else:
        print("bbbbbbbbbbb")
    data = open(result_file, 'rb')
    response = HttpResponse(data)
    #response = StreamingHttpResponse(FileWrapper(data))
    response['Content-Type'] = 'video/mp4'
    #content_dis = 'attachment; filename='+result_file
    #response['Content-Disposition'] = content_dis
    #response['Content-Length'] = os.path.getsize(result_file)
    return response
    data.close
    return HttpResponse("0")

def result(request):
    a, b, c, d = 0, 0, 0, 0
    file=open("../../SiamMask/Video/processed/result.txt", "r")
    content=file.read()
    for i in content.split(" "):
        if i == '0':
            a=a+1
        elif i == '1':
            b=b+1
        elif i == '2':
            c=c+1
        elif i == '3':
            d=d+1
    file.close
    return HttpResponse(str(a) + "," + str(b) + "," + str(c) + "," + str(d))
