from django.apps import AppConfig


class MydjangoConfig(AppConfig):
    name = 'myDjango'
