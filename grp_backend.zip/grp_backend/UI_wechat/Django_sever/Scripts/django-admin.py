#!C:\Users\超级卢本伟\Desktop\大三课本\NewDjango\Scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
