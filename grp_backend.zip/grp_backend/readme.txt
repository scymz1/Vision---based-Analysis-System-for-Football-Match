This is the explanation file in details for developers who would transplant this core function algorithm



Third-party dependencies:
- Cython==0.29.4
- colorama==0.3.9
- numpy==1.15.4
- requests==2.21.0
- fire==0.1.3
- torch==0.4.1
- matplotlib==2.2.3
- numba==0.39.0
- scipy==1.1.0
- h5py==2.8.0
- pandas==0.23.4
- tqdm==4.29.1
- tensorboardX==1.6
- opencv_python==3.4.3.18
- torch==0.4.1
- torchvision==0.2.1

* note that these dependencies are provided by the file 'requirements.txt' appended in the source code of Siammask
* note that the version of each library does not need to strictly conform with the recommandation. However, the version of the library 'Pillow' (maybe a sub-library in one of these libraries) should be less than 7.0.0, otherwise it causes problems.



source code structure:
/Siammask/data/...
	  /datasets/...
	  /experiments/...
	  /models/...
	  /tools/demo.py
	            /test.py
	  /utils/...

* The two highlighted files (demo.py, test.py) are mainly modified.
  As in test.py we changed the pattern of the returning bounding box, from totating rect to right rect.
  In demo.py, we implement main functions required by this project.

* Elaboration of important lines of code:
  (note that the line number could not be precise)
	In demo.py:
	line 59: location = state['ploygon'] (returns the index of current bounding box with the structure of [left-upper X, left-upper Y, width, hight])
	line 62: save_path = '../resultSet/'+str(f)+'.jpg' (the save path of tracking result by pictures, could be porperly modified)
	line 68: cv2.imwrite(save_path, resized) (save the resized picture)
	line 85: data = [cv2.imread(imf, cv2.IMREAD_GRAYSCALE) for imf in data_files] (load pictures for classification with the structure of [img])
	line 89: lenet = torch.load('net.pkl') (load pretrained classification network from the path)
	line 100: result.append(prediction_y) ('result' is the array contains the classification results in enumerate order)

* Note that the three path appeared are encouraged to be modified as relative paths.
* Note that 'net.pkl' is the net model file.



How to integrate the software:
Basically, two ways are recommanded:
	1. directly modifies the 'demo.py' and connect your code with it if possible.
	2. use linux script files (ones in .shell format) or system script command in your code to seperately run the algorithm.
		(Firstly put the trainning video into one folder, eg. put video shooting.mp4 into 			folder home/zmh/桌面/XXX，then open cmd and input following commands:
		cd grp
		bash execute.sh home/zmh/桌面/XXX
		then the program runs automatically)
