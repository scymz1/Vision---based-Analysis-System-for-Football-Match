#!/usr/bin/env python
# coding: utf-8

# In[1]:


import cv2 as cv
import numpy as np


# In[1]:


def getTarget(ori_img, points, save_path):
    x, y, w, h = points
    target = ori_img[y:(y+h), x:(x+w), :]
    resized = cv.resize(target, (50, 50))
    cv.imwrite(save_path, resized)


# In[2]:


# path; target_pos; x_start; y_start; width; hight
# function defined to save the tracking object under local path (the area within the bounding box)
# done within every frame

def getTarget1(ori_img, points, save_path):
    #cv.imshow('OriginalPicture', ori_img)
    target_box = getBound(points)
    target = ori_img[target_box[0][0][0][1]:target_box[0][3][0][1], target_box[0][0][0][0]:target_box[0][1][0][0], :]
    resized = cv.resize(target, (50, 50))
    cv.imwrite(save_path, resized)
    #cv.imshow('target', target)
    return target_box
        


# In[3]:


# function defined to get the minimum right bounding rectangle of a given bounding box
def getBound(points):
    bound_width = max(abs(points[0][0][0][0]-points[0][2][0][0]), abs(points[0][1][0][0]-points[0][3][0][0]))
    bound_hight = max(abs(points[0][0][0][1]-points[0][2][0][1]), abs(points[0][1][0][1]-points[0][3][0][1]))
    x_mid = (points[0][0][0][0]+points[0][2][0][0])/2
    y_mid = (points[0][0][0][1]+points[0][2][0][1])/2
    left_upper = [x_mid-bound_width/2,y_mid-bound_hight/2]
    right_upper = [x_mid+bound_width/2,y_mid-bound_hight/2]
    left_bottom = [x_mid-bound_width/2,y_mid+bound_hight/2]
    right_bottom = [x_mid+bound_width/2,y_mid+bound_hight/2]
    box = [np.array([left_upper, right_upper, right_bottom, left_bottom], np.int32).reshape((-1, 1, 2))]
    return box


# In[5]:


ori_img = cv.imread('C:\\Users\\41713\\Desktop\\test.jpg')
path = 'C:\\Users\\41713\\Desktop\\target.jpg'
pto = np.array([[0, 0], [0, 0], [0, 0], [0, 0]], np.int32)

getTarget(ori_img, pto, path)


# In[57]:


ori_img = cv.imread('C:\\Users\\41713\\Desktop\\test.jpg')
path = 'C:\\Users\\41713\\Desktop\\target.jpg'

pts = np.array([[100, 200], [80, 400], [300, 500], [280, 300]], np.int32)
pts = [pts.reshape((-1, 1, 2))]
box = getTarget(ori_img, pts, path)

cv.polylines(ori_img, pts, True, (200, 200, 200))
cv.polylines(ori_img, box, True, (200, 20, 200))
cv.imshow('lined', ori_img)
cv.waitKey()
cv.destroyAllWindows()


# In[17]:


# 使用cv2.polylines()画多条直线
line1 = np.array([[100, 20],  [300, 40]], np.int32).reshape((-1, 1, 2))
line2 = np.array([[80, 60],  [280, 80]], np.int32).reshape((-1, 1, 2))
line3 = np.array([[100, 20],  [80, 60]], np.int32).reshape((-1, 1, 2))
line4 = np.array([[300, 40],  [280, 80]], np.int32).reshape((-1, 1, 2))

# 定义四个顶点坐标, 顶点个数：4，矩阵变成4*1*2维
pts = np.array([[100, 20], [80, 60], [280, 80], [300, 40]], np.int32)
pts = [pts.reshape((-1, 1, 2))]
lines = [line1, line2, line3, line4]

print(pts[0][1][0])
cv.polylines(ori_img, pts, True, (200, 200, 200))
cv.polylines(ori_img, ptss, True, (200, 20, 200))
cv.imshow('lined', ori_img)
cv.waitKey()
cv.destroyAllWindows()

#getTarget(ori_img, x, y, width, hight, path)


# In[10]:


img = cv.imread('C:\\Users\\41713\\Desktop\\test.jpg')
cv.imshow('OriginalPicture', img)
print(img.shape)

snap_shot = img[100:200, 100:300, :]
cv.imshow("cut",snap_shot);
cv.waitKey()
cv.destroyAllWindows()


# In[ ]:


# 将图片高和宽分别赋值给x，y
x, y = img.shape[0:2]
# 缩放到原来的二分之一，输出尺寸格式为（宽，高）
img_test1 = cv.resize(img, (int(y / 2), int(x / 2)))
cv.imshow('resizedPicture', img_test1)
cv.waitKey()

